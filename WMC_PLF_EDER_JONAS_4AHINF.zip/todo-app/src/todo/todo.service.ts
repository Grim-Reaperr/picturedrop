import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateTodoDto } from './dto/create-todo.dto';

@Injectable()
export class TodoService {
  private todos = [];
  private countID = 1;

  create(createTodoDto: CreateTodoDto) { 
    const newTodo = {
      id: this.countID.toString(),
      ...createTodoDto,
    };
    this.todos.push(newTodo);
    this.countID++;
    return newTodo;
  }

  findAll() {
    return this.todos;
  }

  findOne(id: string) {
    const todo = this.todos.find((task) =>
       task.id === id);
    if (!todo) {
      throw new NotFoundException(id + " wurd nicht gefunden");
    }
    return todo;
  }

  update(id: string, updateTodoDto: Partial<CreateTodoDto>) {
    const todo = this.findOne(id);
    Object.assign(todo, updateTodoDto);
    return todo;
  }

  remove(id: string) {
    const index = this.todos.findIndex((task) =>
       task.id === id);
    if (index === -1) {
      throw new NotFoundException(id + " wurde nicht gefunden");
    }
    this.todos.splice(index, 1);
 
  }
}

