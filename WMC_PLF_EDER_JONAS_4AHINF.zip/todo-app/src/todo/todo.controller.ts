import { Controller, Get, Post, Body, Param, Patch, Delete } from '@nestjs/common';
import { TodoService } from './todo.service';
import { CreateTodoDto } from './dto/create-todo.dto';

//localhost:3000 ist der Standardport

@Controller('todos')  // Der normale Pfad für die Endpunkte lautet todos
export class TodoController {
  constructor(private readonly todoService: TodoService) { }

    // POST /todos: Erstellt eine neue Aufgabe
    //{
    //   "title": "Zimmer aufräumen",
    //   "description": "mama sagt ich soll den saustall aufräumen",
    //   "isDone": false
    // }
    
    // mit isDone kann ich regeln ob die Aufgabe erledigt ist oder nicht

  @Post()
  create(@Body() createTodoDto: CreateTodoDto) {
    return this.todoService.create(createTodoDto); // Verwendet die Create aus dem todo.service
  }

  @Get()  // GET /todos: Gibt alle Aufgaben zurück
  findAll() {
    return this.todoService.findAll();
  }

  @Get(':id') // GET /todos/ ID  Gibt die Aufgabe mit der gesuchten ID zurück
  findOne(@Param('id') id: string) {
    return this.todoService.findOne(id); // Verwendet die FindOne aus dem todo.service
  }

  @Patch(':id') // PATCH /todos/ ID  Aktualisiert die Aufgabe mit der gesuchten ID
  update(@Param('id') id: string, @Body() updateTodoDto: Partial<CreateTodoDto>) {
    return this.todoService.update(id, updateTodoDto); // Verwendet die Update aus dem todo.service
  }
  // DELETE /todos/ ID  Löscht die Aufgabe mit der gesuchten ID
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.todoService.remove(id);   // Verwendet die Remove aus dem todo.service
  }
}
