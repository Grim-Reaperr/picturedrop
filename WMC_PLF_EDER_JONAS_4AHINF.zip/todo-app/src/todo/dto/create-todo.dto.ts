import { IsString, IsNotEmpty, IsBoolean } from 'class-validator';

export class CreateTodoDto {
  @IsString() // Titel muss ein String sein & darf nicht leer sein.
  @IsNotEmpty() 
  title: string;

  @IsString() // muss ein String sein
  description: string;

  @IsBoolean() // isDone  mus ein Boolean sein muss
  isDone: boolean;
}